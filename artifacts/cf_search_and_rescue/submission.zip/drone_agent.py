import os
import math
import hashlib
DUPGUARD=os.environ.get('KT_DUPGUARD','1')=='1'
from pathlib import Path
import numpy as np
import onnxruntime as ort
_H=Path(__file__).resolve().parent
ON=os.environ.get('KT_ON','1')=='1'
CFG={
 'forest':   (350,15,10.0,8.0,5.0,40,120,8.0,0),
 'city':     (450,25,10.0,6.0,5.0,40,250,4.5,1),
 'mountain': (750,25,10.0,6.0,5.0,40,250,4.5,0),
 'village':  (450,15,10.0,8.0,5.0,40,120,8.0,0,0.75),
}
TYPES=tuple(t for t in os.environ.get('KT_TYPES','forest,village,city,mountain').split(',') if t)
LB=('city','open','mountain','village','warehouse','forest')
SIM_DT=0.02
VW=float(os.environ.get('KT_VETO_WARM','0.02'))
def _dfeat(depth):
 d=np.asarray(depth,np.float32)
 if d.ndim==3 and d.shape[-1]==1:
  d=d[...,0]
 if d.ndim!=2:
  d=np.reshape(d,d.shape[:2])
 d=np.clip(d,0.0,1.0)
 gx=np.abs(np.diff(d,axis=1))
 gy=np.abs(np.diff(d,axis=0))
 pc=np.percentile(d,[1,5,10,25,50,75,90,95,99])
 v=[float(d.min()),float(d.mean()),float(d.std()),float(d.max())]
 v += [float(p) for p in pc]
 v += [float((d<=0.1).mean()),float((d<=0.25).mean()),float((d>=0.95).mean()),
  float((d>=0.999).mean()),float((d<=0.001).mean()),
  float(gx.mean()+gy.mean()),float(((gx>0.05).mean()+(gy>0.05).mean())/2.0)]
 h,w=d.shape
 tm,tn,tx=[],[],[]
 for y0 in np.linspace(0,h,5,dtype=int)[:-1]:
  y1=int(y0+h // 4)
  for x0 in np.linspace(0,w,5,dtype=int)[:-1]:
   x1=int(x0+w // 4)
   t=d[y0:y1,x0:x1]
   tm.append(float(t.mean())); tn.append(float(t.min())); tx.append(float(t.max()))
 return v+tm+tn+tx
class _Net:
 def __init__(self,p):
  b=open(p,'rb').read()
  d,h=(int(x) for x in np.frombuffer(b[:4],np.uint16)); o=4
  n1=d*h; n2=h*6
  self.w1=np.frombuffer(b[o:o+n1],np.int8).reshape(d,h).astype(np.float32); o += n1
  self.w2=np.frombuffer(b[o:o+n2],np.int8).reshape(h,6).astype(np.float32); o += n2
  self.s1,self.s2=np.frombuffer(b[o:o+8],np.float32); o += 8
  self.b1=np.frombuffer(b[o:o+2*h],np.float16).astype(np.float32); o += 2*h
  self.b2=np.frombuffer(b[o:o+12],np.float16).astype(np.float32); o += 12
  self.mu=np.frombuffer(b[o:o+2*d],np.float16).astype(np.float32); o += 2*d
  self.sd=np.frombuffer(b[o:o+2*d],np.float16).astype(np.float32)
  self.w1 *= self.s1; self.w2 *= self.s2
 def probs(self,f):
  x=(f-self.mu)/self.sd
  hd=np.maximum(x@self.w1+self.b1,0)
  z=hd@self.w2+self.b2
  z -= z.max()
  e=np.exp(z)
  return e/e.sum()
class _Cls:
 def __init__(self):
  self.net=_Net(_H/'typenet.bin')
  self.reset()
 def reset(self):
  self.ps=np.zeros(6); self.n=0
  self.latched=set(); self.is_mountain=False
 def update(self,tick,state,depth):
  if tick>600 or tick%5:
   return
  s=np.asarray(state,np.float32).reshape(-1)
  sf=np.zeros(141,np.float32)
  sf[:min(141,s.size)]=s[:141]
  f=np.asarray([float(tick),float(tick)*SIM_DT]+sf.tolist()+_dfeat(depth),np.float32)
  self.ps += self.net.probs(f); self.n += 1
  avg=self.ps/self.n
  i=int(np.argmax(avg)); lab=LB[i]
  bar=0.5 if lab=='warehouse' else 0.7
  if self.n>=3 and avg[i]>=bar:
   self.latched.add(lab)
   if lab=='mountain':
    self.is_mountain=True
  if self.n>=40 and avg[4]>=0.15:
   self.latched.add('warehouse')
 def settled(self,t):
  return t in self.latched
 def mtn_risk(self):
  if self.is_mountain or 'mountain' in self.latched: return True
  if self.n<3: return True
  return float((self.ps/self.n)[2])>=0.25
def _warm(rgb):
 im=np.asarray(rgb,np.float32).reshape(256,256,3)[128:]
 r,g,b=im[...,0],im[...,1],im[...,2]
 return float(((r>g+0.03) & (g>=b)).mean())
_BOX=np.array([25.0,30.0,30.0,25.0,12.0,20.0])
CVR=9.0
def _ccore(origin,pad):
 xs=np.arange(-48.0,50.0,2.0)
 X,Y=np.meshgrid(xs,xs)
 pts=np.stack([X.ravel(),Y.ravel()],1)
 dc=np.linalg.norm(pts-origin,axis=1)
 dp=np.linalg.norm(pts-pad,axis=1)
 m=(dc<=33.0)&(dp<=83.0)
 pts,dc,dp=pts[m],dc[m],dp[m]
 ax=np.abs(pts).max(1)
 dens=np.zeros(len(pts))
 for bb in _BOX:
  dens[ax<=bb] += 1.0/(6.0*(2*bb) ** 2)
 w=dens/(1+np.exp(-(30.0-dc)))/(1+np.exp(-(80.0-dp)))
 return pts,w,dc
def _bous(core,lane,spacing,cap,pos):
 core=np.asarray(core,np.float64)
 if core.shape[0]<4:
  return []
 k=np.round(core[:,0]/lane).astype(int)
 o=np.lexsort((np.where(k%2==0,core[:,1],-core[:,1]),k))
 path=core[o]
 sel=[path[0]]
 for q in path[1:]:
  if float(np.linalg.norm(q-sel[-1]))>=spacing:
   sel.append(q)
 w=sel[:cap]
 if len(w)>=2 and np.linalg.norm(w[-1]-pos)<np.linalg.norm(w[0]-pos):
  w=w[::-1]
 return [np.asarray(x,np.float64) for x in w]
def _wps(origin,pad,pos,lane,spacing,cap):
 xs=np.arange(-48.0,50.0,2.0)
 X,Y=np.meshgrid(xs,xs)
 pts=np.stack([X.ravel(),Y.ravel()],1)
 dc=np.linalg.norm(pts-origin,axis=1)
 dp=np.linalg.norm(pts-pad,axis=1)
 m=(dc<=33.0) & (dp<=83.0)
 pts,dc,dp=pts[m],dc[m],dp[m]
 ax=np.abs(pts).max(1)
 dens=np.zeros(len(pts))
 for bb in _BOX:
  dens[ax<=bb] += 1.0/(6.0*(2*bb) ** 2)
 w=dens/(1+np.exp(-(30.0-dc)))/(1+np.exp(-(80.0-dp)))
 core=pts
 if w.sum()>0:
  o=np.argsort(-w)
  cw=np.cumsum(w[o])/w.sum()
  core=pts[o[:int(np.searchsorted(cw,0.9))+1]]
 if core.shape[0]<4:
  core=pts[dc<=30.0]
 if not core.shape[0]:
  return []
 k=np.round(core[:,0]/lane).astype(int)
 o=np.lexsort((np.where(k%2==0,core[:,1],-core[:,1]),k))
 path=core[o]
 sel=[path[0]]
 for q in path[1:]:
  if float(np.linalg.norm(q-sel[-1]))>=spacing:
   sel.append(q)
 w=sel[:cap]
 if len(w)>=2 and np.linalg.norm(w[-1]-pos)<np.linalg.norm(w[0]-pos):
  w=w[::-1]
 return [np.asarray(x,np.float64) for x in w]
BRAKE = os.environ.get('KT_BRAKE', '1') == '1'
DESCEND = os.environ.get('KT_DESCEND', '0') == '1'
DS_T0 = int(os.environ.get('KT_DS_T0', '900'))
DS_AGL_HI = float(os.environ.get('KT_DS_AGL_HI', '0.97'))
DS_AGL_LO = float(os.environ.get('KT_DS_AGL_LO', '0.60'))
DS_Z = float(os.environ.get('KT_DS_Z', '-0.55'))
OBGATE = os.environ.get('KT_OBGATE', '1') == '1'
MEYE = os.environ.get('KT_MEYE', '0') == '1'
ME_P = float(os.environ.get('KT_ME_P', '0.55'))
ME_T0 = int(os.environ.get('KT_ME_T0', '600'))
ME_EVERY = int(os.environ.get('KT_ME_EVERY', '5'))
_CAM_F, _CAM_U = 0.13, 0.05
ME_P_LO = float(os.environ.get('KT_ME_P_LO', '0.26'))
ME_RGB_OK = float(os.environ.get('KT_ME_RGB_OK', '0.271'))
ME_RGB_EVERY = int(os.environ.get('KT_ME_RGB_EVERY', '8'))
ME_RGB_BUDGET = int(os.environ.get('KT_ME_RGB_BUDGET', '34'))
ME_RGB_TTL = int(os.environ.get('KT_ME_RGB_TTL', '60'))
OB_TH = float(os.environ.get('KT_OB_TH', '0.12'))
OB_FRAC = float(os.environ.get('KT_OB_FRAC', '0.10'))
OB_HOLD = int(os.environ.get('KT_OB_HOLD', '30'))
OB_COOL = int(os.environ.get('KT_OB_COOL', '150'))
LOCK = os.environ.get('KT_LOCK', '1') == '1'
BR_P = float(os.environ.get('KT_BR_P', '0.90'))        # presence bar to arm the brake
BR_R = float(os.environ.get('KT_BR_R', '6.0'))         # range bar to arm the brake (m)
BR_HOLD = int(os.environ.get('KT_BR_HOLD', '150'))     # ticks the brake stays armed
BR_A3 = float(os.environ.get('KT_BR_A3', '0.28'))      # 0.28 * SPEED_LIMIT = 0.84 m/s
BR_BUDGET = int(os.environ.get('KT_BR_BUDGET', '900')) # total braked ticks per episode

LK_P = float(os.environ.get('KT_LK_P', '0.90'))        # presence bar to accept a fix
LK_RMIN = 1.0
LK_RMAX = float(os.environ.get('KT_LK_RMAX', '25.0'))  # trust the range only this far
LK_MAXP = int(os.environ.get('KT_LK_MAXP', '1200'))     # drop a latch the policy never bit after this many ticks
LK_YIELD = os.environ.get('KT_LK_YIELD', '0') == '1'   # stop steering once the policy tracks on its own (m0>=2)
LK_N = int(os.environ.get('KT_LK_N', '6'))             # accepted fixes before latching
LK_TOL = float(os.environ.get('KT_LK_TOL', '5.0'))     # m spread allowed inside a latch
LK_EMA = 0.25
LK_STALE = int(os.environ.get('KT_LK_STALE', '700'))   # ticks hovering on a dud -> drop
LK_TICK0 = 60                                          # never latch during take-off
GEOM = os.environ.get('KT_LK_GEOM', 'fuse')            # ground | range | fuse

_TAN_H = math.tan(math.radians(30.0))    # BaseAviary: fov=60 vertical, aspect=1
_CAM_L = 0.0397                          # cf2x arm length; eye = pos + [0,0,L]
_IMG = 256.0


def _cam_axes(rpy):
    r,p,y=(float(rpy[0]),float(rpy[1]),float(rpy[2]))
    cr,sr,cp,sp,cy,sy=(math.cos(r),math.sin(r),math.cos(p),math.sin(p),math.cos(y),math.sin(y))
    fwd=np.array([cy*cp,sy*cp,-sp],np.float64)
    up=np.array([cy*sp*cr+sy*sr,sy*sp*cr-cy*sr,cp*cr],np.float64)
    return fwd,up,np.cross(fwd,up)
def _meas_world(u,v,cz,pos,rpy):
    fwd,up,right=_cam_axes(rpy)
    cam=np.asarray(pos,np.float64)+fwd*_CAM_F+up*_CAM_U
    return cam+right*(u*cz)+up*(v*cz)+fwd*cz
def _sig(x):
    return 1.0 / (1.0 + math.exp(-max(-40.0, min(40.0, float(x)))))


def _decode_victim(z):
    """Raw dbg_victim logits -> (p, col_px, row_px, range_m)."""
    p = _sig(z[0])
    u = (_sig(z[1]) * 3.0 - 1.0) * 255.0
    v = (_sig(z[2]) * 3.0 - 1.0) * 255.0
    r = _sig(z[3]) * 2.0 * 30.0
    return p, u, v, r


def _cam_ray(rpy, u_px, v_px):
    """Unit world-frame ray through pixel (col, row) of the drone's depth camera.

    BaseAviary._getDroneImages: eye = pos + [0,0,L]; target = R(rpy) @ [1000,0,0];
    up = world +z; computeProjectionMatrixFOV(fov=60 vertical, aspect=1).  gluLookAt
    gives camera right s = normalize(fwd x up_world) and camera up = s x fwd.
    Confirmed in flight: on the run-in to village s790000 the victim holds column
    ~130 (image centre 127.5) while its row climbs 188 -> 216, i.e. dead ahead and
    sinking, then the detector blinds out at 2.1 m horizontal / 3.1 m above.
    """
    cp = math.cos(float(rpy[1])); sp = math.sin(float(rpy[1]))
    cy = math.cos(float(rpy[2])); sy = math.sin(float(rpy[2]))
    fwd = np.array([cy * cp, sy * cp, -sp], np.float64)
    n = float(np.linalg.norm(fwd))
    if n < 1e-9:
        return None
    fwd /= n
    s = np.cross(fwd, np.array([0.0, 0.0, 1.0]))
    ns = float(np.linalg.norm(s))
    if ns < 1e-6:                     # looking straight up/down: no valid right axis
        return None
    s /= ns
    upc = np.cross(s, fwd)
    ndx = (2.0 * float(u_px) / _IMG) - 1.0
    ndy = 1.0 - (2.0 * float(v_px) / _IMG)
    ray = fwd + (ndx * _TAN_H) * s + (ndy * _TAN_H) * upc
    nr = float(np.linalg.norm(ray))
    if nr < 1e-9:
        return None
    return ray / nr


def _fix_ground(pos, rpy, u_px, v_px, agl):
    """Intersect the pixel ray with the local ground plane z = pos_z - AGL.

    Preferred over the detector's own range head, which is badly compressed:
    regressed against truth over 689 confident ticks (village s790000 + forest
    s790039) the decoded `rng` maps 0->4.1 m, 8->5.4 m, 20->8.6 m, 30->18.7 m,
    i.e. it is a monotone proximity ordinal, not metres.  The ray direction, by
    contrast, is exact geometry, and state[162] * MAX_RAY_DISTANCE is a real
    downward-lidar AGL, so the ground intersection needs no calibration at all.
    """
    if not (0.5 <= agl <= 19.0):        # 20.0 is the lidar's saturation value
        return None
    ray = _cam_ray(rpy, u_px, v_px)
    if ray is None or ray[2] > -0.05:   # not looking down: no ground solution
        return None
    eye = np.array([pos[0], pos[1], pos[2] + _CAM_L], np.float64)
    t = (float(pos[2]) - agl - eye[2]) / float(ray[2])
    if not (0.5 <= t <= 45.0):
        return None
    return eye + t * ray


def _fix_range(pos, rpy, u_px, v_px, rng):
    """Fallback when the ground plane is unusable: pixel ray + linearised range.

    d3 ~= 0.177 * rng + 3.94 (residual sd 0.38 m) over the rng <= 12 band where
    the head is least distorted; outside that band the caller must not use this.
    """
    ray = _cam_ray(rpy, u_px, v_px)
    if ray is None:
        return None
    d = 0.177 * float(rng) + 3.94
    eye = np.array([pos[0], pos[1], pos[2] + _CAM_L], np.float64)
    return eye + d * ray


class _VictimTrack:
    """World-frame memory of the policy's own victim detector.

    Latch-on-evidence: until LK_N mutually-consistent confident fixes arrive the
    object reports nothing at all, so the wrapper above it is bit-identical to
    UID_130.  A latch is dropped (and its point blacklisted) if the drone loiters
    on it without the episode ending, so a false positive costs a detour, never
    the flight.
    """

    def __init__(self):
        self.reset()

    def reset(self):
        self.xy = None          # latched victim (2,) world
        self.z = 0.0
        self.n = 0
        self.cand = []          # recent accepted fixes, pre-latch
        self.hot = -10 ** 9     # last tick with a close, confident fix
        self.last = -10 ** 9    # last tick with any accepted fix
        self.near_since = None
        self.bad = []           # blacklisted points
        self.braked = 0
        self.fixes = 0

    def _blacklisted(self, q):
        for b in self.bad:
            if float(np.linalg.norm(q - b)) < 6.0:
                return True
        return False

    def update(self, tick, pose, dv, clue_xy):
        """pose = (pos3, rpy3) used for the frame `dv` was computed from."""
        if dv is None or pose is None or tick < LK_TICK0:
            return
        p, u, v, r = _decode_victim(dv)
        if p < BR_P:
            return
        if r <= BR_R:
            self.hot = tick                       # arms the brake (no geometry needed)
        if not LOCK or p < LK_P or not (LK_RMIN <= r <= LK_RMAX):
            return
        pos, rpy, agl = pose
        q = None
        if GEOM in ('ground', 'fuse'):
            q = _fix_ground(pos, rpy, u, v, agl)
        if q is None and GEOM in ('range', 'fuse') and r <= 12.0:
            q = _fix_range(pos, rpy, u, v, r)
        if q is None or not np.all(np.isfinite(q)):
            return
        qxy = q[0:2]
        # the victim is guaranteed inside the clue disk (SAR_SEARCH_RADIUS = 30)
        if clue_xy is not None and float(np.linalg.norm(qxy - clue_xy)) > 32.0:
            return
        # and it is on the ground, i.e. below the drone
        if not (-14.0 <= float(q[2]) - float(pos[2]) <= 1.0):
            return
        if self._blacklisted(qxy):
            return
        self.fixes += 1
        self.last = tick
        if self.xy is not None:
            if float(np.linalg.norm(qxy - self.xy)) <= 3.0 * LK_TOL:
                self.xy = (1.0 - LK_EMA) * self.xy + LK_EMA * qxy
                self.z = (1.0 - LK_EMA) * self.z + LK_EMA * float(q[2])
            return
        self.cand.append((tick, qxy, float(q[2])))
        self.cand = [c for c in self.cand if tick - c[0] <= 120]
        if len(self.cand) >= LK_N:
            pts = np.asarray([c[1] for c in self.cand[-LK_N:]], np.float64)
            c0 = pts.mean(0)
            if float(np.max(np.linalg.norm(pts - c0, axis=1))) <= LK_TOL:
                self.xy = c0
                self.z = float(np.mean([c[2] for c in self.cand[-LK_N:]]))
                self.n = tick

    def accept_fix(self, tick, q, pos, clue_xy):
        """Externally-localised fix (our mountain depth eye): same gates+latch."""
        qxy=np.asarray(q[0:2],np.float64)
        if clue_xy is not None and float(np.linalg.norm(qxy-clue_xy))>32.0:
            return
        if not (-25.0<=float(q[2])-float(pos[2])<=1.0):
            return
        if self._blacklisted(qxy):
            return
        self.fixes+=1; self.last=tick
        if self.xy is not None:
            if float(np.linalg.norm(qxy-self.xy))<=3.0*LK_TOL:
                self.xy=(1.0-LK_EMA)*self.xy+LK_EMA*qxy
                self.z=(1.0-LK_EMA)*self.z+LK_EMA*float(q[2])
            return
        self.cand.append((tick,qxy,float(q[2])))
        self.cand=[c for c in self.cand if tick-c[0]<=200]
        if len(self.cand)>=4:
            pts=np.asarray([c[1] for c in self.cand[-4:]],np.float64)
            c0=pts.mean(0)
            if float(np.max(np.linalg.norm(pts-c0,axis=1)))<=LK_TOL:
                self.xy=c0; self.z=float(np.mean([c[2] for c in self.cand[-4:]])); self.n=tick
                self.hot=tick
    def tick_end(self, tick, pos_xy, m0=0.0):
        """Drop a latch the drone has sat on without the episode ending,
        or one the detector has stopped supporting, or one the policy has
        refused to track for a long time (phantom)."""
        if self.xy is None:
            return
        if m0 < 2.0 and tick - self.n > LK_MAXP:  # latched this long, policy never bit
            self.bad.append(self.xy.copy())
            self.xy = None; self.cand = []; self.near_since = None
            self.hot = -10 ** 9
            return
        d = float(np.linalg.norm(self.xy - np.asarray(pos_xy, np.float64)))
        if d <= 4.0:
            if self.near_since is None:
                self.near_since = tick
            elif tick - self.near_since > LK_STALE:
                self.bad.append(self.xy.copy())
                self.xy = None
                self.cand = []
                self.near_since = None
                self.hot = -10 ** 9   # a dud latch must not keep the brake armed
        else:
            self.near_since = None

    def offset(self, pos_xy, m0=0.0):
        if self.xy is None or (LK_YIELD and m0 >= 2.0):
            return None
        return self.xy - np.asarray(pos_xy, np.float64)

    def brake(self, tick, m0, pos_xy):
        """True when the confirm speed cap (1.0 m/s) is worth enforcing."""
        if not BRAKE or self.braked >= BR_BUDGET:
            return False
        if m0 >= 3.0:            # the policy's own terminal controller: never touch it
            return False
        if tick - self.hot <= BR_HOLD:
            return True
        off = self.offset(pos_xy)
        return off is not None and float(np.linalg.norm(off)) <= 3.0



class DroneFlightController:
 def __init__(self,*,model_path=None,providers=None):
  so=ort.SessionOptions()
  so.intra_op_num_threads=2
  so.inter_op_num_threads=1
  so.execution_mode=ort.ExecutionMode.ORT_SEQUENTIAL
  so.add_session_config_entry("session.intra_op.allow_spinning","0")
  self.session=ort.InferenceSession(str(model_path or _H/'policy.onnx'),so,
           providers=providers or ["CPUExecutionProvider"])
  self._ms=next(int(i.shape[0]) for i in self.session.get_inputs()
      if i.name=="memory_tensor")
  self._in={i.name for i in self.session.get_inputs()}
  self._outs={o.name for o in self.session.get_outputs()}
  self._has_dv='dbg_victim' in self._outs
  self._trk=_VictimTrack() if ON else None
  self._meye=None
  self._mrgb=None
  if ON and MEYE:
   try:
    mp=_H/'victim_depth_m.onnx'
    if mp.exists():
     so2=ort.SessionOptions(); so2.intra_op_num_threads=2; so2.inter_op_num_threads=1
     self._meye=ort.InferenceSession(str(mp),so2,providers=['CPUExecutionProvider'])
     self._meye_in=self._meye.get_inputs()[0].name
    rp=_H/'victim_rgb_m.onnx'
    if rp.exists():
     so3=ort.SessionOptions(); so3.intra_op_num_threads=2; so3.inter_op_num_threads=1
     self._mrgb=ort.InferenceSession(str(rp),so3,providers=['CPUExecutionProvider'])
     self._mrgb_in=self._mrgb.get_inputs()[0].name
   except Exception:
    self._meye=None
  self._cls=_Cls() if ON else None
  self.reset()
 def reset(self):
  self.memory_tensor=np.zeros(self._ms,np.float32)
  self.tick=0
  self._h={15: [],25: []}
  self._pad=None
  self._on=False
  self._cfg=None
  self._w=None
  self._i=0
  self._adv=0
  self._cv=None
  self._cvt=0
  self.route='king'
  self._sup=None; self._mass=None; self._w0=None
  self._dv=None
  self._pose=None
  self._clue0=None
  self._dsu=False
  self._last_key=None
  self._last_out=None
  self._rgb_ok_t=-10**9
  self._rgb_used=0
  self._rq_me=False
  self._ob_until=-1
  self._ob_ready=0
  if self._trk is not None:
   self._trk.reset()
  if self._cls:
   self._cls.reset()
 def _vbuild(self,pos,clue,c):
  if self._sup is None:
   sup,w,dc=_ccore(pos[0:2]+clue,self._pad)
   self._sup=sup; self._w0=w; self._mass=w.copy(); self._dc=dc
  wps=_bous(self._core(0.9),c[3],c[4],c[5],pos[0:2])
  if not wps:
   self._mass=self._w0.copy()
   wps=_bous(self._core(0.9),c[3]*0.65,c[4]*0.7,c[5],pos[0:2])
  if not wps:
   wps=_bous(self._sup[self._dc<=30.0],c[3],c[4],c[5],pos[0:2])
  return wps
 def _core(self,frac):
  w=self._mass; t=float(w.sum())
  if t<=0:
   return np.zeros((0,2))
  o=np.argsort(-w)
  cw=np.cumsum(w[o])/t
  return self._sup[o[:int(np.searchsorted(cw,frac))+1]]
 def _swept(self,xy):
  if self._mass is not None:
   self._mass[np.linalg.norm(self._sup-np.asarray(xy,np.float64),axis=1)<=CVR]=0.0
 def _stype(self):
  c=self._cls
  if c.is_mountain:
   return 'mountain' if 'mountain' in TYPES else None
  for t in TYPES:
   if t!='mountain' and c.settled(t):
    return t
  return None
 def _obs_key(self,observation):
  try:
   h=hashlib.blake2b(digest_size=16)
   h.update(np.ascontiguousarray(np.asarray(observation['state'],np.float32)).tobytes())
   h.update(np.ascontiguousarray(np.asarray(observation['depth'],np.float32)).tobytes())
   rgb=observation.get('rgb') if hasattr(observation,'get') else None
   if rgb is not None:
    h.update(np.ascontiguousarray(np.asarray(rgb,np.float32)).tobytes())
   return h.digest()
  except Exception:
   return None
 def act(self,observation):
  if DUPGUARD:
   k=self._obs_key(observation)
   if k is not None and k==self._last_key and self._last_out is not None:
    return self._last_out.copy()
   self._last_key=k
  out=self._act(observation)
  if DUPGUARD:
   self._last_out=np.asarray(out,np.float32).reshape(-1).copy()
  return out
 def _act(self,observation):
  self.tick += 1
  rq=False
  st=np.asarray(observation["state"],np.float32).reshape(-1).copy()
  if ON and self._cls:
   pos=st[0:3].astype(np.float64)
   if self._pad is None:
    self._pad=pos[0:2].copy()
   try:
    if self._clue0 is None:
     self._clue0=pos[0:2]+st[-2:].astype(np.float64)
   except Exception:
    pass
   if self._trk is not None and not self._cls.mtn_risk():
    try:
     self._trk.update(self.tick,self._pose,self._dv,self._clue0)
    except Exception:
     pass
   self._cls.update(self.tick,st,np.asarray(observation["depth"],np.float32))
   for pd,hs in self._h.items():
    if self.tick%pd==0:
     hs.append(pos[0:2].copy())
     if len(hs)>20:
      hs.pop(0)
   if not self._on:
    t=self._stype()
    c=CFG.get(t) if t else None
    if c and self.tick>=c[0]:
     hs=self._h[c[1]]
     if len(hs)>=20:
      hp=np.asarray(hs)
      if float(np.max(np.linalg.norm(hp-hp[0],axis=1)))<c[2]:
       if c[8] and self._cv!='ok':
        if self._cv!='block':
         rgb=observation.get('rgb') if hasattr(observation,'get') else None
         fr=np.asarray(rgb,np.float32) if rgb is not None else None
         if fr is not None and float(fr.max())>0.01:
          self._cv='block' if _warm(fr)>=VW else 'ok'
          if self._cv=='ok':
           self._on=True; self._cfg=c
         elif self._cvt<3:
          rq=True; self._cv='req'; self._cvt += 1
       else:
        self._on=True; self._cfg=c
   if self._on:
    c=self._cfg
    if self._w is None:
     if len(c)>9:
      self._w=self._vbuild(pos,st[-2:].astype(np.float64),c)
     else:
      self._w=_wps(pos[0:2]+st[-2:].astype(np.float64),self._pad,
        pos[0:2],c[3],c[4],c[5])
     self._i=0; self._adv=self.tick
    if len(self._w):
     self._i=min(self._i,len(self._w)-1)
     wp=self._w[self._i]
     if float(np.linalg.norm(wp-pos[0:2]))<c[7] or self.tick-self._adv>c[6]:
      if len(c)>9:
       self._swept(wp)
      nx=self._i+1
      if nx>=len(self._w):
       if len(c)>9:
        rb=self._vbuild(pos,st[-2:].astype(np.float64),c)
        if rb:
         self._w=rb
       nx=0
      self._i=nx
      self._adv=self.tick
      wp=self._w[self._i]
     ob=False
     if OBGATE and not self._cls.mtn_risk():
      try:
       if self.tick<self._ob_until:
        ob=True
       elif self.tick>=self._ob_ready:
        dctr=np.asarray(observation["depth"],np.float32).reshape(256,256,1)[96:160,96:160,0]
        if float((dctr<OB_TH).mean())>=OB_FRAC:
         ob=True
         self._ob_until=self.tick+OB_HOLD
         self._ob_ready=self.tick+OB_HOLD+OB_COOL
      except Exception:
       ob=False
     off=wp-pos[0:2]
     bl=c[9] if len(c)>9 else 1.0
     if bl<1.0:
      off=bl*off+(1.0-bl)*st[-2:].astype(np.float64)
     if not ob:
      st[-2]=np.float32(off[0]); st[-1]=np.float32(off[1])
     self.route='king+tour'
   try:
    _mreg=(self._meye is not None and self._trk is not None and self._cls.is_mountain
        and self.tick>=ME_T0
        and (float(self.memory_tensor[0]) if self._ms else 0.0)<2.0)
    if _mreg and self._mrgb is not None:
     rgbf=observation.get('rgb') if hasattr(observation,'get') else None
     if rgbf is not None:
      fr=np.asarray(rgbf,np.float32)
      if fr.size and float(np.mean(np.abs(fr)))>0.004:
       r=fr.reshape(256,256,3).reshape(128,2,128,2,3).mean(axis=(1,3))
       r=np.ascontiguousarray(r,np.float32)
       p_rgb=_sig(float(np.asarray(self._mrgb.run(None,{self._mrgb_in:r})[0],np.float32).reshape(5)[0]))
       if p_rgb>=ME_RGB_OK:
        self._rgb_ok_t=self.tick
    if _mreg and self.tick%ME_EVERY==0:
     darr=np.asarray(observation["depth"],np.float32).reshape(256,256,1)
     o5=np.asarray(self._meye.run(None,{self._meye_in:darr})[0],np.float32).reshape(5)
     pme=_sig(float(o5[0]))
     bar=ME_P_LO if (self.tick-self._rgb_ok_t)<=ME_RGB_TTL else ME_P
     if pme>=bar and float(st[162])<=0.6:
      cz=float(np.exp(np.clip(float(o5[3]),-3.0,4.0)))
      q=_meas_world(float(o5[1]),float(o5[2]),cz,pos,st[3:6].astype(np.float64))
      if np.all(np.isfinite(q)):
       self._trk.accept_fix(self.tick,q,pos,self._clue0)
    self._rq_me=(_mreg and self._mrgb is not None and self._rgb_used<ME_RGB_BUDGET
        and self.tick%ME_RGB_EVERY==0
        and st.size>162 and float(st[162])<=0.5)
    if self._trk is not None and not self._cls.mtn_risk():
     lk=self._trk.offset(pos[0:2],float(self.memory_tensor[0]) if self._ms else 0.0)
     if lk is not None:
      st[-2]=np.float32(lk[0]); st[-1]=np.float32(lk[1])
     self._trk.tick_end(self.tick,pos[0:2],
          float(self.memory_tensor[0]) if self._ms else 0.0)
    self._pose=(pos.copy(),st[3:6].astype(np.float64).copy(),
         float(st[162])*20.0 if st.size>162 else 20.0)
   except Exception:
    pass
  feed={"depth": np.asarray(observation["depth"],np.float32).reshape(256,256,1),
    "state": st,"memory_tensor": self.memory_tensor}
  if "rgb" in self._in:
   rgb=observation.get("rgb") if hasattr(observation,"get") else None
   feed["rgb"]=(np.asarray(rgb,np.float32).reshape(256,256,3)
      if rgb is not None else np.zeros((256,256,3),np.float32))
  names=["action","memory_tensor_out"]
  if ON and self._has_dv:
   names.append("dbg_victim")
  res=self.session.run(names,feed)
  a,m=res[0],res[1]
  self.memory_tensor=np.asarray(m,np.float32).reshape(self._ms)
  out=np.asarray(a,np.float32).reshape(-1)
  try:
   if DESCEND and ON and self._cls is not None and out.shape[0]>=4 \
      and self._cls.is_mountain and self.tick>=DS_T0 and st.size>162:
    m0d=float(self.memory_tensor[0]) if self._ms else 0.0
    agl=float(st[162])
    if m0d<2.0 and agl>=DS_AGL_HI:
     self._dsu=True
    if getattr(self,'_dsu',False) and (m0d>=2.0 or agl<=DS_AGL_LO):
     self._dsu=False
    if getattr(self,'_dsu',False) and float(out[2])>DS_Z:
     out=out.copy(); out[2]=np.float32(DS_Z)
     if float(out[3])<0.45:
      out[3]=np.float32(0.45)
   if ON and self._has_dv and len(res)>2:
    self._dv=np.asarray(res[2],np.float32).reshape(-1)
   if self._trk is not None and out.shape[0]>=4 and not self._cls.mtn_risk():
    m0=float(self.memory_tensor[0]) if self._ms else 0.0
    if self._pose is not None and self._trk.brake(self.tick,m0,self._pose[0][0:2]):
     if float(out[3])>BR_A3:
      out=out.copy(); out[3]=np.float32(BR_A3)
      self._trk.braked+=1
  except Exception:
   pass
  if rq and out.shape[0]>=6:
   out=out.copy(); out[5]=1.0
  if getattr(self,'_rq_me',False) and out.shape[0]>=6 and float(out[5])<=0.5:
   out=out.copy(); out[5]=1.0
   self._rgb_used+=1
  return out

# r2
